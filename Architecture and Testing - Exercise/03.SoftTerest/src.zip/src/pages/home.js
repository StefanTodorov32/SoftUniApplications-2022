const homeView = document.getElementById('homeView')

export function showHome(context){
    context.showSection(homeView)
}