import { updateNav } from "./auth.js"
import { router } from "./router.js"
const registerSection = document.getElementById('form-sign-up')
const registerBtn = registerSection.querySelector('button')

registerBtn.addEventListener('click', onregister)
async function onregister(e) {
    const form = e.target.parentElement
    let [email, password, repass] = form.querySelectorAll('input')
    email = email.value
    password = password.value
    repass = repass.value
    if (!email || !password || !repass) {
        alert('Empty fields!')
        return
    }
    if (password.length < 2) {
        alert('Password must be more than 8 chars!')
        return
    }
    if (password !== repass) {
        alert('Passwords dont match!')
        return
    }
    try {
        const response = await fetch(`http://localhost:3030/users/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email, password
            })
        })
        const data = await response.json()
        localStorage.setItem('useData', JSON.stringify({ data }))
        updateNav()
        router('/')
    } catch (err){
        alert(err.message)
    }
    
}

export function renderRegister() {
    registerSection.style.display = 'block'

}