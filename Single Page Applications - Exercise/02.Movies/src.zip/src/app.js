import { router } from './router.js'
import { updateNav } from './auth.js'
router('/')
updateNav()
const navi = document.querySelector('.container')
navi.addEventListener('click', (e) => {
    e.preventDefault()
    if (e.target.tagName == 'A') {
        let url = new URL(e.target.href)
        router(url.pathname)
    }
})
document.getElementById('add-movie-button').addEventListener('click',(e)=>{
    e.preventDefault()
    let url = new URL(e.target.href)
})