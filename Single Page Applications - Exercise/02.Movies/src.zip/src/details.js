const movieList = document.getElementById('movies-list')
const moviesBtn = movieList.querySelectorAll('button')

