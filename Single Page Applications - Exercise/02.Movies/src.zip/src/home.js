import { updateNav } from './auth.js'
import { router } from './router.js'
const homeSection = document.getElementById('home-page')
const movieSection = document.getElementById('movie')
const moviesList = document.getElementById('movies-list')

moviesList.addEventListener('click', (e)=>{
    if (e.target.tagName == 'BUTTON') {
        e.preventDefault()
        const id = e.target.dataset.id
        console.log(id);
    }
})

export function renderHome() {
    homeSection.style.display = 'block'
    updateNav()
    movieSection.style.display = 'block'
    displayMovies()
    
}
async function displayMovies() {
    moviesList.replaceChildren()
    const movies = await getMovies()
    moviesList.replaceChildren(...movies.map(createMovie));

}
async function getMovies() {
    const res = await fetch(`http://localhost:3030/data/movies`)
    const data = res.json()
    return data
}
function createMovie(data) {
    const element = document.createElement('div');
    element.className = 'card mb-4';
    element.innerHTML = `<img class="card-img-top" src="${data.img}"
    alt="Card image cap" width="400">
    <div class="card-body">
    <h4 class="card-title">${data.title}</h4>
    </div>
    <div class="card-footer">
    <a  href="/details/${data._id}">
        <button data-id = "${data._id}" type="button" class="btn btn-info">Details</button>
    </a>
    </div>`;

    return element;
}
export async function renderLogout() {
    localStorage.clear()
    router('/')
}
window.getMovies = getMovies