import { updateNav } from "./auth.js"
import { router } from "./router.js"

const loginSection = document.getElementById('form-login')
const loginBtn = loginSection.querySelector('button')
export function renderLogin(){
    loginSection.style.display = 'block'
}
loginBtn.addEventListener('click', onLogin)

async function onLogin(e){
    e.preventDefault()
    const form = e.target.parentElement
    let [email, password] = form.querySelectorAll('input')
    email = email.value
    password = password.value
    if (!email || !password) {
        alert('Empty fields!')
        return
    }
    try {
        const response = await fetch(`http://localhost:3030/users/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email, password
            })
        })
        const data = await response.json()
        localStorage.setItem('useData', JSON.stringify({ data }))
        updateNav()
        router('/')
    } catch (err){
        alert(err.message)
    }
}