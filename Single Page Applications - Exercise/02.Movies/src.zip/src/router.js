import { renderRegister } from "./register.js"
import { renderLogin } from "./login.js"
import { renderHome, renderLogout } from "./home.js"
import { renderAddMovie } from "./addMovie.js"
const routes = {
    '/': renderHome,
    '/logout': renderLogout,
    '/register': renderRegister,
    '/login': renderLogin,
    '/createmovie': renderAddMovie
}
export function router(path) {
    hideContent()
    const renderer = routes[path]
    renderer()
}

export function hideContent() {
    const sections = document.querySelectorAll('section')
    for (const section of sections) {
        section.style.display = 'none'
    }
}