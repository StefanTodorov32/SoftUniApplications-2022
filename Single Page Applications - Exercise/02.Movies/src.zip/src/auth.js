export function updateNav() {
    const user = JSON.parse(localStorage.getItem('useData'))
    const welcomeMsg = document.getElementById('welcome-msg');

    if (user) {
        document.querySelectorAll('.user').forEach(e => e.style.display = 'inline-block')
        document.querySelectorAll('.guest').forEach(e => e.style.display = 'none');
        welcomeMsg.textContent = `Welcome, ${user.data.email}`;
    } else {
        document.querySelectorAll('.user').forEach(e => e.style.display = 'none');
        document.querySelectorAll('.guest').forEach(e => e.style.display = 'inline-block');
        welcomeMsg.textContent = ''
    }
}