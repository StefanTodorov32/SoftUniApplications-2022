import {router} from './router.js'

const addMovie = document.querySelector('#add-movie')
const addMovieBtn = addMovie.querySelector('button')
addMovieBtn.addEventListener('click', onAdd)
export function renderAddMovie(){
    addMovie.style.display = 'block'
}


async function onAdd(e){
    e.preventDefault()
    let [title, img] = addMovie.querySelectorAll('input')
    let description = addMovie.querySelector('textarea').value
    title = title.value
    img = img.value
    const body ={
        title, description, img
    }
    const token = JSON.parse(localStorage.getItem('useData')).data.accessToken
    const response = await fetch(`http://localhost:3030/data/movies`,{
        method: 'POST',
        headers:{
            'Content-Type':'application/json',
            'X-Authorization': token
        },
        body: JSON.stringify(body)
    })
    router('/')
}